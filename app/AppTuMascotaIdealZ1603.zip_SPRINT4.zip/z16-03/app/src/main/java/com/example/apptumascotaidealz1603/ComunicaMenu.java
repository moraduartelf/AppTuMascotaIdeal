package com.example.apptumascotaidealz1603;

public interface ComunicaMenu {
    //Implementamos un metodo para comunicar el menu con la actividad mediante un boton.
    public void menu(int cualBoton);
}
